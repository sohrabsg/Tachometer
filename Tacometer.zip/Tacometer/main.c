
//**********************************************************
//
//Tachometer: this program uses one lazer and measures the
//	period between each time the lazer gets interrupted, these interrupts happen on every falling edge.
//The pins used in this project are:
//	Pin PD0: This pin generates a PWM signal with period of 1.8 Micro Seconds, it can be used as an alternative source to check
//		for the devices functionality.
//	Pin PC4: This pin is a wide timer which counts the number of cycles in between each interrupt.
//	Pin PA3: Tis pin is used to determine the direction
//	Pin PB0: This pin is the receiver of UART1 (not used in this project)
//	Pin PB1: Transmitter pin for UART1, sends the data to putty through a serial connection.
//Wiring:
//	the get the data: Attach the output of the circuit to pin PC4
//	if the data is not received and the connection needs to be checked:
//		Attach a wire from PD0 to PC4 (remove the circuits output) and connect the tiva to computer through the serial wire
//		to check if the problem is from the wireless connection.
//
//Author: Sohrab Gousheh
//		  Electrical and Computer Engineering Dep.
//		  SUNY Oswego
//
//
//**********************************************************

#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "driverlib/debug.h"
#include "driverlib/pwm.h"
#include "driverlib/pin_map.h"
#include "inc/hw_gpio.h"
#include "driverlib/rom.h"
#include "driverlib/timer.h"
#include "inc/hw_ints.h"
#include "driverlib/interrupt.h"
#include "inc/hw_timer.h"
#include "driverlib/uart.h"
#include "utils/uartstdio.h"
#include "driverlib/fpu.h"


//**********************************************************
//
//					Defines
//
//**********************************************************

#define PWM_FREQUENCY 55
//55Hz frequency

//**********************************************************
//
//					Global variables
//
//**********************************************************

volatile float f_ui32Time;
volatile uint32_t g_ui32Count;
volatile uint32_t g_ui32FlagVar = 0;
volatile uint32_t g_ui32FlagVar2 = 0;
volatile int g_ui32Num = 0;
volatile int g_ui32Dir;

//**********************************************************
//
//					Prototypes
//
//**********************************************************

void TIMER_B_Handler(void);
void Peripheral(void);
void PinConfiguration(void);


void main(void){

	volatile uint32_t ui32Load;
	volatile uint32_t ui32PWMClock;
	volatile uint8_t ui8Adjust = 83;
	char theString [8];

	SysCtlClockSet(SYSCTL_SYSDIV_5|SYSCTL_USE_PLL|SYSCTL_OSC_MAIN|SYSCTL_XTAL_16MHZ);
	//Sets the CPU's clock at 40MHz

	SysCtlPWMClockSet(SYSCTL_PWMDIV_64);
	//PWM clock is set to 625 kHz (64 is the devider) (SYSCLK/64)

	Peripheral();
	//Calls the peripheral functions declared, sets up the peripherals

	PinConfiguration();
	//calls the pin configuration function to set up the pins needed

	TimerConfigure(WTIMER0_BASE, (TIMER_CFG_SPLIT_PAIR | TIMER_CFG_A_CAP_TIME_UP));
	//This configuration is for the WTimer0 and it will spread it in to 2 timer
	//Configure TimerA as a half-width one-shot timer

    TimerControlEvent(WTIMER0_BASE, TIMER_A, TIMER_EVENT_NEG_EDGE);
    // Configure the counter (TimerA) to count both edges.

    TimerEnable(WTIMER0_BASE, TIMER_A);
    // Enable the timers.

    IntMasterEnable(); //enable processor interrupts

    UARTConfigSetExpClk(UART1_BASE, SysCtlClockGet(), 115200,(UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE | UART_CONFIG_PAR_NONE));
    UARTStdioConfig(1, 57600, SysCtlClockGet());


	ui32PWMClock = SysCtlClockGet() / 64;
	ui32Load = (ui32PWMClock / PWM_FREQUENCY) - 1;

	PWMGenConfigure(PWM1_BASE, PWM_GEN_0, PWM_GEN_MODE_DOWN);
	PWMGenPeriodSet(PWM1_BASE, PWM_GEN_0, ui32Load);
	//set period to 55Hz

	PWMPulseWidthSet(PWM1_BASE, PWM_OUT_0, ui8Adjust * ui32Load / 1000);
	PWMOutputState(PWM1_BASE, PWM_OUT_0_BIT, true);
	PWMGenEnable(PWM1_BASE, PWM_GEN_0);

    FPUEnable();
    //Enables floating point unit

    FPULazyStackingEnable();
    //This function saves a spot on the stack for when there is a floating point
    //it will be placed on on that spot

    GPIOIntTypeSet(GPIO_PORTA_BASE, GPIO_PIN_3,GPIO_FALLING_EDGE);//set the type of interrupt for Pin PA3

	TimerIntEnable(WTIMER0_BASE, TIMER_CAPA_EVENT); // Enable timer capture A event interrupt
	IntPrioritySet(INT_WTIMER0A, 0); // Configure Wide Timer 1A interrupt priority as 0
	IntEnable(INT_WTIMER0A); // Enable Wide Timer 1A interrupt


	while(1){

		if (g_ui32FlagVar == 1){
			sprintf(theString, "%f" , f_ui32Time);
			UARTprintf( "%i,%s,%i \n \r " , g_ui32Num , theString, g_ui32Dir);
			g_ui32FlagVar = 0; //this stops the if statement from rewriting the same result (waits for new result to come in)

		}

		SysCtlDelay(1000);

	}
}



void TIMER_B_Handler(void){

	uint32_t ui32Status;

	ui32Status = TimerIntStatus(WTIMER0_BASE, true);
	//get interrupt status

	TimerIntClear(WTIMER0_BASE, ui32Status);
	//clear the interrupt


	g_ui32Count = TimerValueGet (WTIMER0_BASE, TIMER_A);

	HWREG(WTIMER0_BASE + TIMER_O_TAV) = 0x00000000; //resets the number of cycles to 0

	f_ui32Time = (float) (g_ui32Count)/(SysCtlClockGet()); //measures the period by devideing the number of cycles by 40MHz

	g_ui32FlagVar = 1; //this flag allows the device to print the result out through UART

	g_ui32Num = g_ui32Num + 1;

	if(GPIOPinRead(GPIO_PORTA_BASE, GPIO_INT_PIN_3)==0x00){ //check the status of PA3 to determine the direction.
		g_ui32Dir = 0; //right;
	}else{
		g_ui32Dir = 1; //left;
	}

}



void Peripheral (void) {

	SysCtlPeripheralEnable(SYSCTL_PERIPH_WTIMER0);
	//Enables the peripheral for the wide timer 0, this peripheral uses Pins 4 and 5 from port C

	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOC);
	//Enables the peripheral of the GPIOC (PortC)

	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);

	SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM1);
	//out put pwm on PD0
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOD);

	SysCtlPeripheralEnable(SYSCTL_PERIPH_UART1);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);
}

void PinConfiguration(void){

	GPIOPinConfigure(GPIO_PC4_WT0CCP0); //This function configures pin PC4 as wide timer 0
	GPIOPinTypeTimer(GPIO_PORTC_BASE, GPIO_PIN_4); //Enables the PC4 pin

	GPIOPinConfigure(GPIO_PA0_U0RX);
	GPIOPinConfigure(GPIO_PA1_U0TX);
	GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);

	GPIOPinTypePWM(GPIO_PORTD_BASE, GPIO_PIN_0);
	//configures PD0 as a pwmtype
	GPIOPinConfigure(GPIO_PD0_M1PWM0);
	//configures PD0 as a PWM output pin for module 1

	// Enable pin PB0 for UART1 U1RX
	GPIOPinConfigure(GPIO_PB0_U1RX);
	// Enable pin PB1 for UART1 U1TX
	GPIOPinConfigure(GPIO_PB1_U1TX);
	GPIOPinTypeUART(GPIO_PORTB_BASE, GPIO_PIN_0 | GPIO_PIN_1);

	//setting laser GPIO pin PA3
	GPIOPinTypeGPIOInput(GPIO_PORTA_BASE, GPIO_PIN_3);
	GPIOPadConfigSet(GPIO_PORTA_BASE,GPIO_PIN_3,GPIO_STRENGTH_2MA,GPIO_PIN_TYPE_STD_WPU);
}



